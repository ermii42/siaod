#include "TestHash.h"
#include "TestBinary.h"
#include "TestBinaryHash.h"

int main() {
    testHash();
    //testBinary();
    //testBinaryHash();
}

