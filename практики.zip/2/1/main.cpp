#include "filefunctions.h"

int main() {
    int choice, code;
    string ln;
    cin >> ln;
    cout << ln<<1<<"       ";
    string filename_inp, filename_out;
    while(true){
        cout<<"Interface\n";
        cout<<"1) create a text file"<<endl;
        cout<<"2) outputting the contents of a text file"<<endl;
        cout<<"3) adding a new record to the end of the file"<<endl;
        cout<<"4) read the value of the number, indicating its serial number in the file, \nand return its value"<<endl;
        cout<<"5) determine the amount of numbers in the file"<<endl;
        cout<<"6) create a new file from the values in the original file by multiplying \neach number by the sum of the first and last numbers in the original file."<<endl;
        cin>>choice;
        switch(choice){
            case 1:
                cout<<"Input file name:";
                cin>>filename_out;
                code=CreateFile(filename_out);
                if (code==-1) cout<<"File does not exist";
                break;
            case 2:
                cout<<"Input file name:";
                cin>>filename_inp;
                code=ReadFile(filename_inp);
                if (code==-1) cout<<"File does not exist";
                break;
            case 3:
                cout<<"Input file name:";
                cin>>filename_out;
                code=AddToEndFile(filename_out);
                if (code==-1) cout<<"File does not exist";
                break;
            case 4:
                cout<<"Input file name:";
                cin>>filename_inp;
                code=FindNumberFile(filename_inp);
                if (code==-1) cout<<"File does not exist";
                else if (code==-2) cout<<"Number not found";
                else cout <<"The index is "<<code;
                break;
            case 5:
                cout<<"Input file name:";
                cin>>filename_out;
                code=CountNumbersFile(filename_out);
                if (code==-1) cout<<"File does not exist";
                else cout<<"The amount of numbers in the file is "<<code;
                break;
            case 6:
                cout<<"Input sourse file name:";
                cin>>filename_inp;
                cout<<"Input new file name:";
                cin>>filename_out;
                code=CreateNewFileFrom(filename_inp, filename_out);
                if (code==-1) cout<<"File does not exist";
                break;
            default:
                break;
        }
        cout<<endl<<endl;
    }
}
