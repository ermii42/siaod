//
// Created by user on 24.09.2022.
//

#ifndef INC_1_FILEFUNCTIONS_H
#define INC_1_FILEFUNCTIONS_H
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

int CreateFile(string filename){
    ofstream out(filename, ios::trunc);
    if(!out) return -1;
    string s;
    int n;
    cout << "Input number of lines in file:";
    cin >> n;
    cout << "Input the number lines:\n";
    getline(cin, s);
    getline(cin, s);
    out << s;
    for(int i=0; i<n-1; i++){
        out<<endl;
        getline(cin, s);
        out << s;
    }
    out.close();
    return 0;
}

int ReadFile(string filename) {
    ifstream inp(filename);
    if(!inp) return -1;
    string s;
    while(!inp.eof()){
        getline(inp, s);
        cout<<s<<endl;
    }
    inp.close();
    return 0;
}

int AddToEndFile(string filename){
    ofstream out(filename, ios::app);
    if(!out) return -1;
    int x;
    cout << "Input the number:";
    cin >> x;
    out << endl << x;
    out.close();
    return 0;
}

int FindNumberFile(string filename){
    ifstream inp(filename);
    if(!inp) return -1;
    int x;
    int k=0;
    int number;
    cout<<"Input number:";
    cin >> number;
    while(!inp.eof()){
        inp >> x;
        k++;
        if (x==number){
            return k;
        }
    }
    inp.close();
    return -2;
}

int CountNumbersFile(string filename) {
    ifstream inp(filename);
    if(!inp) return -1;
    int x;
    int k=0;
    while(!inp.eof()){
        inp >> x;
        k++;
    }
    inp.close();
    return k;
}

int SumLastAndFirstNumbers(string filename){
    ifstream inp(filename);
    if(!inp) return -1;
    int last=0;
    int first;
    inp>>first;
    while(!inp.eof()){
        inp >> last;
    }
    inp.close();
    return last+first;
}

int CreateNewFileFrom(string filename, string newfilename){
    ifstream inp(filename);
    ofstream out(newfilename, ios::trunc);
    if(!inp) return -1;
    if(!out) return -1;
    string s;
    string x;
    int number=SumLastAndFirstNumbers(filename);
    getline(inp, s);
    stringstream ss(s);
    while(getline(ss, x, ' ')){
        out << stoi(x)*number << ' ';
    }
    while(!inp.eof()){
        out << endl;
        getline(inp, s);
        stringstream ss(s);
        while(getline(ss, x, ' ')){
            out << stoi(x)*number << ' ';
        }
    }
    inp.close();
    out.close();
    return 0;
}

#endif //INC_1_FILEFUNCTIONS_H
