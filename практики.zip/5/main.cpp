#include "testTree.h"
#include "testBinTreeSearch.h"
#include "windows.h"


int main() {
    SetConsoleOutputCP(CP_UTF8);
    testBinTreeSearch();
    testTree();

    return 0;
}
