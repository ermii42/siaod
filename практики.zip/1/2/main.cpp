#include <iostream>
#include <chrono>
#include <ctime>
#include <vector>
using namespace std;

vector<int> vec;
bool prov(int ch){
    for(int i=0;i<vec.size();i++){
        if(vec[i] == ch) return false;
    }
    return true;
}

// Вывод позиций битов числа
void output_bit(int x, int plus){
    int k=0;
    while((1<<k) <= x){
        if((x&(1<<k)) != 0){
            cout << k + plus << " ";
        }
        k++;
    }
}


void generator(int number){
    srand(time(NULL));
    //int a = 9999999 - 1000000;
    int a;
    int k=0;
    while(k!=number){
        a = 9999999 - rand()%8999999;
        if(prov(a) == true){
            vec.push_back(a);
            k++;
        }
    }
}

int main() {
    const int size=10000000/32;
    unsigned int bit[size]; // инициализация бинарного массива
    long int n;
    int number;
    cout << "Input amount of numbers:";
    cin >> n;
    // заполнение бинарного массива нулями
    for(int i=0; i<size; i++){
        bit[i] = 0;
    }
    //generator(n);
    srand(time(NULL));
    auto start = std::chrono::steady_clock::now();

    // заполнение бинарного массива входными числами
    for(int i=0; i<n; i++){
        //number = vec[i];
        cin >> number;
        bit[number/32] = bit[number/32] | (1<<number%32);
    }
    // вывод отсортированных чисел
    for(int i=0; i<size; i++){
        if(bit[i]!=0) output_bit(bit[i], i*32);
    }
    auto stop = chrono::steady_clock::now();
    auto elapsed_ms = chrono::duration<double>(stop - start);
    cout << "\nThe time: " << elapsed_ms.count()*1000.0 << " ms";
}
