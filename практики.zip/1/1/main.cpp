#include <iostream>
using namespace std;

void bin_output(int x)
{
    int n=sizeof(int)*8;
    unsigned  maska=(1<<(n-1));
    for(int i=1; i<=n;i++)
    {
        cout<<((x&maska)>>(n-i));
        maska=maska>>1;
    }
    cout<<endl;
}

int main() {
    int number;

    int max_bit = (1<<31);
    cout << "Input number:";
    cin >> number;
    cout<<"The input number in binary is:\n\t";
    bin_output(number);
    int mask_one=0x0828;
    int mask_zero = ~((1<<3) | (1<<2) | (1<<1) | 1);

    number = number | mask_one;
    cout << "1)\t";
    bin_output(number);
    number = number & (mask_zero);
    cout << "2)\t";
    bin_output(number);
    number = number << 7;
    cout << "3)\t";
    bin_output(number);
    number = number >> 7;
    cout << "4)\t";
    bin_output(number);
    int n;
    cout << "Enter the digit:";
    cin>>n;
    number = number | max_bit>>(31-n)^max_bit>>(30-n);
    cout << "5)\t";
    bin_output(number);

    return 0;
}
