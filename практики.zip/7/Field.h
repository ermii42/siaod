#ifndef INC_7_FIELD_H
#define INC_7_FIELD_H
using namespace std;

class Field {
    int n = 0, m = 0;
    int** arr;
public:
    Field(int n, int m);

    int getPathsNumber();
    void getArr();
};

Field::Field(int n, int m) {

    this->m = std::max(n, m);
    this->n = m + n - this->m;
    this->arr = new int *[this->n];
    for (int i = 0; i < this->n; i++) {
        arr[i] = new int[this->m];
    }

}

int Field::getPathsNumber() {
    // помечаем все ходы вправо
    for(int j=0; j<m; j++){
        arr[0][j] = 1;
    }
    for(int i=1; i<n; i++){
        arr[i][i] = arr[i-1][i] * 2;
        for(int j=i+1; j<m; j++){
            arr[i][j] = arr[i-1][j] + arr[i][j-1];
        }
    }
    return arr[n-1][m-1];

}

void Field::getArr() {
    for(int i=0; i<n; i++){
        for(int j=0; j<m;j++){
            cout << arr[i][j] <<" ";
        }
        cout<<endl;
    }
}

#endif //INC_7_FIELD_H
