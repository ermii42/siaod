//
// Created by user on 18.12.2022.
//

#ifndef INC_7_CELL_H
#define INC_7_CELL_H

class Cell { /**Клетка*/
    int wayNumber = 1;
public:

    Cell() = default;

    int getWayNumber() const;

    void setWayNumber(int wayNumber);
};

int Cell::getWayNumber() const {
    return wayNumber;
}

#endif //INC_7_CELL_H
